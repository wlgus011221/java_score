package project_score;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class LoginMenu {
	// Field
	private Connection conn;
	private Scanner scanner = new Scanner(System.in);
		
		
	// Constructor
	public LoginMenu() {
		try {
			// JDBC Driver 등록
			Class.forName("oracle.jdbc.OracleDriver");
				
			// 연결하기
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/orcl", "java", "oracle");
		} catch(Exception e) {
			e.printStackTrace();
			exit();
		}
	}
		
	// Method
	public void LoginMainMenu() {
		System.out.println();
		System.out.println("1.교수 | 2.학생 | 3.종료");
		System.out.println("--------------------------------------------");
		System.out.print("메뉴 선택 : ");
		String menuNo = scanner.nextLine();
					
		if(menuNo.equals("1")) {
			proLoginMethod proLoginMethod = new proLoginMethod();
			System.out.println();
			System.out.println("1.로그인 | 2.회원가입 | 3.이전으로");
			System.out.println("--------------------------------------------");
			System.out.print("메뉴 선택 : ");
			menuNo = scanner.nextLine();
			switch(menuNo) {
			case "1" -> proLoginMethod.proLogin();
			case "2" -> proLoginMethod.proJoin();
			case "3" -> LoginMainMenu();
			}
		} else if(menuNo.equals("2")) {
			stuLoginMethod stuLoginMethod = new stuLoginMethod();
			System.out.println();
			stuLoginMethod.stuLogin();
		} else if(menuNo.equals("3")) {
			exit();
		}
	}
	
	public void exit() {
		if(conn != null) {
			try {
				conn.close();
			} catch(SQLException e) {}
		}
		System.out.println("종료합니다.");
		System.exit(0);
	}
}
