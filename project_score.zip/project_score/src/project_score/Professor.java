package project_score;

import lombok.Data;

@Data
public class Professor {
	private String proId;
	private String proPw;
	private String proName;
	private String proEmail;
	private int proAge;
	private String proClass;
}