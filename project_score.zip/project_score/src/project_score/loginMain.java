package project_score;

public class loginMain {
	public static void main(String[] args) {
		LoginMenu loginMenu = new LoginMenu();
		loginMenu.LoginMainMenu();
	}
}