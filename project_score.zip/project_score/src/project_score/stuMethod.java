package project_score;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class stuMethod {
	// Field
	private Connection conn;
	private Score stu = new Score();
			
			
	// Constructor
	public stuMethod() {
		try {
			// JDBC Driver 등록
			Class.forName("oracle.jdbc.OracleDriver");
				
			// 연결하기
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/orcl", "java", "oracle");
		} catch(Exception e) {
			e.printStackTrace();
			exit();
		}
	}
			
	// Method
	public void stuSearch(String stuNo) {
		try {
			String sql = "" + "SELECT stuName, stuNo, stuBirth, kor, mat, eng, sum, sum/3, grade "
					+ "FROM students "
					+ "WHERE stuNo=?";
			
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, stuNo);
			ResultSet rs = pstmt.executeQuery();
			
			if(rs.next()) {
				stu.setStuName(rs.getString("stuName"));
				stu.setStuNo(rs.getString("stuNo"));
				stu.setStuBirth(rs.getString("stuBirth"));
				stu.setKor(rs.getInt("kor"));
				stu.setMat(rs.getInt("mat"));
				stu.setEng(rs.getInt("eng"));
				stu.setSum(rs.getInt("sum"));
				stu.setGrade(rs.getString("grade"));
				
				System.out.println();
				System.out.println("[ " + stuNo + " 학생 ]");
				System.out.println("이름 : " + stu.getStuName());
				System.out.println("학번 : " + stu.getStuNo());
				System.out.println("생년월일 : " + stu.getStuBirth());
				System.out.println("국어 : " + stu.getKor());
				System.out.println("수학 : " + stu.getMat());
				System.out.println("영어 : " + stu.getEng());
				System.out.println("합 : " + stu.getSum());
				System.out.println("평균 : " + stu.getSum() / 3);
				System.out.println("등급 : " + stu.getGrade());
				System.out.println();
			}
		} catch(Exception e) {
			e.printStackTrace();
			exit();
		}
		LoginMenu loginMenu = new LoginMenu();
		loginMenu.LoginMainMenu();
	}
	
	public void exit() {
		if(conn != null) {
			try {
				conn.close();
			} catch(SQLException e) {}
		}
		System.out.println("종료합니다.");
		System.exit(0);
	}
}
