package project_score;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class proLoginMethod {
	// Field
	private Connection conn;
	private Scanner scanner = new Scanner(System.in);
	private Professor pro = new Professor();
		
		
	// Constructor
	public proLoginMethod() {
		try {
			// JDBC Driver 등록
			Class.forName("oracle.jdbc.OracleDriver");
			
			// 연결하기
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/orcl", "java", "oracle");
		} catch(Exception e) {
			e.printStackTrace();
			exit();
		}
	}
		
	// Method
	public void proLogin() {			
		int chance = 0;
			
		while (chance < 3) { // 3번 틀리면 프로그램 종료
			System.out.print("ID : ");
			String scannerId = scanner.nextLine(); // 아이디 입력
				
			System.out.print("PW : ");
			String scannerPw = scanner.nextLine(); // 비밀번호 입력
			
			try {
				String sql = "" + "SELECT proId, proPw "
						+ "FROM professors "
						+ "WHERE proId=?";
				
				PreparedStatement pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, scannerId);
				ResultSet rs = pstmt.executeQuery();
				
				if(rs.next()) {
					pro.setProId(rs.getString("proId"));
					pro.setProPw(rs.getString("proPw"));
					
					if(scannerId.equals(pro.getProId())) { // 아이디가 일치하는지 확인
						if(scannerPw.equals(pro.getProPw())) { // 비밀번호가 일치하는지 확인
							System.out.println("로그인 성공");
							proMethod pro = new proMethod();
							pro.mainMenu(); // 아이디와 비밀번호가 일치하면 교수 메인메뉴로 이동
						}
					}
					else {
						System.out.println("일치하지 않습니다."); // 로그인 실패 메시지 출력
					}
				}
				chance ++;
			} catch(Exception e) {
				e.printStackTrace();
				exit();
			}
		}
		LoginMenu loginMenu = new LoginMenu();
		loginMenu.LoginMainMenu();
	}
		
	
	public void proJoin() {
		System.out.println("[교수 회원가입]");
		System.out.print("ID : ");
		pro.setProId(scanner.nextLine());
		System.out.print("PW : ");
		pro.setProPw(scanner.nextLine());
		System.out.print("이름 : ");
		pro.setProName(scanner.nextLine());
		System.out.print("이메일 : ");
		pro.setProEmail(scanner.nextLine());
		System.out.print("반 : ");
		pro.setProClass(scanner.nextLine());
		System.out.print("나이 : ");
		pro.setProAge(scanner.nextInt());
		scanner.nextLine();
		
		try {
			// 매개변수화된 SQL문 작성
			String sql = "" + "INSERT INTO professors (proId, proPw, proName, proEmail, proClass, proAge) "
					+ "VALUES(?, ?, ?, ?, ?, ?)";
			
			// PreparedStatement 얻기 및 값 지정
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, pro.getProId());
			pstmt.setString(2, pro.getProPw());
			pstmt.setString(3, pro.getProName());
			pstmt.setString(4, pro.getProEmail());
			pstmt.setString(5, pro.getProClass());
			pstmt.setInt(6, pro.getProAge());
			
			// SQL문 실행
			pstmt.executeUpdate();
			
			// PreparedStatement 닫기
			pstmt.close();
		} catch(Exception e) {
			e.printStackTrace();
			exit();
		}
		LoginMenu loginMenu = new LoginMenu();
		loginMenu.LoginMainMenu();
	}	
	
	
	public void exit() {
		if(conn != null) {
			try {
				conn.close();
			} catch(SQLException e) {}
		}
		System.out.println("종료합니다.");
		System.exit(0);
	}
}